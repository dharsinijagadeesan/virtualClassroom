import React from 'react';
import './GlobalProfiles.css';
import success from '../sidebar-logos/image.png';  // Importing the CSS file

const GlobalProfiles = () => {
  return (
    <div className="global-profiles-container">
      <h2 className="section-title">Global Platform Profiles</h2>
      <div className='top'>
      <div className="profile-card">
        <div className="profile-info">
          <img src={success} alt="Success Icon" className="profile-icon" />
          <p>Add your External Profile</p>
          <a href="#" className="edit-link">Edit External Profile</a>
        </div>
      </div>
      <div className="profile-card" style={{marginLeft:'80px'}}>
        <div className="profile-info">
          <img src={success} alt="Success Icon" className="profile-icon" />
          <p>Add your External Profile</p>
          <a href="#" className="edit-link">Edit External Profile</a>
        </div>
      </div>
      </div>
    </div>
  );
};

export default GlobalProfiles;
