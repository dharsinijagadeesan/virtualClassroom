import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

function AssessmentActivity() {
  return (
    <div className="my-4" style={{ paddingLeft: '30px', paddingRight: '30px' }}>
      <div className="row">
        {/* Assessment Activity Section */}
        <div className="col-md-6">
          <h4 className="mb-4" style={{ color: '#202124' }}>Assessment Activity</h4>
          <div className="row">
            <div className="col-md-6 mb-3">
              <div className="card text-center p-3 shadow-sm" style={{ backgroundColor: '#f8f9fa', border: 'none' }}>
                <h6 style={{ color: '#5f6368' }}>Tests Assigned</h6>
                <h2 style={{ color: '#202124' }}>131</h2>
              </div>
            </div>
            <div className="col-md-6 mb-3">
              <div className="card text-center p-3 shadow-sm" style={{ backgroundColor: '#f8f9fa', border: 'none' }}>
                <h6 style={{ color: '#5f6368' }}>Tests Completed</h6>
                <h2 style={{ color: '#202124' }}>27</h2>
              </div>
            </div>
            <div className="col-md-6 mb-3">
              <div className="card text-center p-3 shadow-sm" style={{ backgroundColor: '#f8f9fa', border: 'none' }}>
                <h6 style={{ color: '#5f6368' }}>Questions Attempted</h6>
                <h2 style={{ color: '#202124' }}>99</h2>
              </div>
            </div>
            <div className="col-md-6 mb-3">
              <div className="card text-center p-3 shadow-sm" style={{ backgroundColor: '#f8f9fa', border: 'none' }}>
                <h6 style={{ color: '#5f6368' }}>Total Time Spent</h6>
                <h2 style={{ color: '#202124' }}>1418 mins</h2>
              </div>
            </div>
          </div>
          <p className="text-muted" style={{ fontSize: '14px', marginTop: '20px' }}>
            Please visit the <a href="#" style={{ color: '#1a73e8' }}>Assessments page</a> for all the active assessments/assignments.
          </p>
        </div>

        {/* Subject Level Accuracy Section */}
        <div className="col-md-6">
          <h4 className="mb-4" style={{ color: '#202124' }}>Subject Level Accuracy</h4>
          <p className="text-muted" style={{ fontSize: '14px', marginBottom: '30px' }}>
            This metric reflects your overall performance across all assessments taken, providing a summary of your accuracy at the subject level. It offers insights into how well you've performed in each subject area, helping you identify strengths and areas for improvement.
          </p>
          <div className="card p-4 shadow-sm" style={{ backgroundColor: '#f8f9fa', border: 'none' }}>
            <div className="d-flex justify-content-between align-items-center mb-2">
              <span style={{ color: '#5f6368', fontWeight: 'bold' }}>Technical</span>
              <span style={{ color: '#202124' }}>71%</span>
            </div>
            <div className="progress" style={{ height: '8px', backgroundColor: '#e8eaed' }}>
              <div
                className="progress-bar"
                role="progressbar"
                style={{ width: '71%', backgroundColor: '#fbbc05' }}
                aria-valuenow="71"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Live Sessions Section */}
      <div className="mt-5">
        <h4 className="mb-2" style={{ color: '#202124' }}>Live Sessions</h4>
        <p className="text-muted" style={{ fontSize: '14px' }}>
          No live sessions are currently taking place, please check back later.
        </p>
      </div>
    </div>
  );
}

export default AssessmentActivity;
