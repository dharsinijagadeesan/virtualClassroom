import React from 'react';
import './Navbar.css';  // Importing your custom CSS

function Navbar() {
  return (
    <div className="navbar-container">
      <h4 className="navbar-title">Welcome, Dharsini J.</h4>
      <button className="navbar-button">Edit Profile</button>
    </div>
  );
}

export default Navbar;
