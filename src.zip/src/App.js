import React from 'react';
import './App.css';  // Custom CSS for overall app layout
import Sidebar from './components/Sidebar';  // Keep Sidebar as a separate component
import Dashboard from './components/Dashboard'; 
import Header from './components/Header';

function App() {
  return (
    <div className="app-container">
      <Sidebar />
      <Header/>
      <Dashboard/>
    </div>
  );
}

export default App;
